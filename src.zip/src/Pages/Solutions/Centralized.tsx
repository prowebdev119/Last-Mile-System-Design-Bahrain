import React from 'react';
import SolutionCategory from '../../Components/SolutionCategory';

const Centralized = () => {
	return <SolutionCategory id={3} title="Centralized and IP TV" description="" />;
};

export default Centralized;
