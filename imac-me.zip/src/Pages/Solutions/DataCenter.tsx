import React from 'react';
import SolutionCategory from '../../Components/SolutionCategory';

const DataCenter = () => {
	return <SolutionCategory id={1} title="Switching and Data Center" description="" />;
};

export default DataCenter;
