import React from 'react';
import SolutionCategory from '../../Components/SolutionCategory';

const Security = () => {
	return <SolutionCategory id={4} title="Security and Surveillance" description="" />;
};

export default Security;
