import React from 'react';
import SolutionCategory from '../../Components/SolutionCategory';

const Radio = () => {
	return <SolutionCategory id={0} title="Radio and Telecommunication" description="" />;
};

export default Radio;
